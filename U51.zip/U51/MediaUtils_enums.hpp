enum class EMediaPlayerOptionBooleanOverride {
    UseMediaPlayerSetting = 0,
    Enabled = 1,
    Disabled = 2,
    EMediaPlayerOptionBooleanOverride_MAX = 3,
};


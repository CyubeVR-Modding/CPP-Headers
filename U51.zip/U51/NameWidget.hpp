#ifndef UE4SS_SDK_NameWidget_HPP
#define UE4SS_SDK_NameWidget_HPP

class UNameWidget_C : public UUserWidget
{
};

#endif

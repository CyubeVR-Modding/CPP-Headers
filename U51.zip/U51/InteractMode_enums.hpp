enum class InteractMode {
    NewEnumerator0 = 0,
    NewEnumerator1 = 1,
    NewEnumerator2 = 2,
    NewEnumerator4 = 3,
    NewEnumerator5 = 4,
    NewEnumerator6 = 5,
    InteractMode_MAX = 6,
};


#ifndef UE4SS_SDK_MainMenuFocusWarningNewNew_HPP
#define UE4SS_SDK_MainMenuFocusWarningNewNew_HPP

class UMainMenuFocusWarningNewNew_C : public UUserWidget
{
    class UWidgetAnimation* WidgetSwitcherChange;
    class UWidgetAnimation* FlyInBorder;
    class UWidgetAnimation* FlyIn;
    class AActor* Parent;

};

#endif

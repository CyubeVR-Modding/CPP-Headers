#ifndef UE4SS_SDK_BP_MacroLibrary_HPP
#define UE4SS_SDK_BP_MacroLibrary_HPP

class ABP_MacroLibrary_C : public AActor
{
};

#endif

enum class ENiagara_AttributeSamplingApplyOutput {
    NewEnumerator0 = 0,
    NewEnumerator1 = 1,
    ENiagara_MAX = 2,
};


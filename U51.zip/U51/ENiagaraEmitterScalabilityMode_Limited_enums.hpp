enum class ENiagaraEmitterScalabilityMode_Limited {
    NewEnumerator0 = 0,
    NewEnumerator1 = 1,
    ENiagaraEmitterScalabilityMode_MAX = 2,
};


enum class OLD2_BlockType {
    NewEnumerator3 = 0,
    NewEnumerator0 = 1,
    NewEnumerator1 = 2,
    NewEnumerator2 = 3,
    OLD2_MAX = 4,
};


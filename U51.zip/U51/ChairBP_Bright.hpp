#ifndef UE4SS_SDK_ChairBP_Bright_HPP
#define UE4SS_SDK_ChairBP_Bright_HPP

class AChairBP_Bright_C : public AChairBP_C
{

    void UserConstructionScript();
};

#endif

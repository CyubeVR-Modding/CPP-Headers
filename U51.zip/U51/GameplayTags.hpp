#ifndef UE4SS_SDK_GameplayTags_HPP
#define UE4SS_SDK_GameplayTags_HPP

#include "GameplayTags_enums.hpp"

struct FGameplayTag
{
    FName TagName;

};

struct FGameplayTagContainer
{
    TArray<FGameplayTag> GameplayTags;
    TArray<FGameplayTag> ParentTags;

};

struct FGameplayTagQuery
{
    int32 TokenStreamVersion;
    TArray<FGameplayTag> TagDictionary;
    TArray<uint8> QueryTokenStream;
    FString UserDescription;
    FString AutoDescription;

};

class UBlueprintGameplayTagLibrary : public UBlueprintFunctionLibrary
{

    bool RemoveGameplayTag(FGameplayTagContainer& TagContainer, FGameplayTag Tag);
    bool NotEqual_TagTag(FGameplayTag A, FString B);
    bool NotEqual_TagContainerTagContainer(FGameplayTagContainer A, FString B);
    bool NotEqual_GameplayTagContainer(const FGameplayTagContainer& A, const FGameplayTagContainer& B);
    bool NotEqual_GameplayTag(FGameplayTag A, FGameplayTag B);
    bool MatchesTag(FGameplayTag TagOne, FGameplayTag TagTwo, bool bExactMatch);
    bool MatchesAnyTags(FGameplayTag TagOne, const FGameplayTagContainer& OtherContainer, bool bExactMatch);
    FGameplayTagContainer MakeLiteralGameplayTagContainer(FGameplayTagContainer Value);
    FGameplayTag MakeLiteralGameplayTag(FGameplayTag Value);
    FGameplayTagQuery MakeGameplayTagQuery(FGameplayTagQuery TagQuery);
    FGameplayTagContainer MakeGameplayTagContainerFromTag(FGameplayTag SingleTag);
    FGameplayTagContainer MakeGameplayTagContainerFromArray(const TArray<FGameplayTag>& GameplayTags);
    bool IsTagQueryEmpty(const FGameplayTagQuery& TagQuery);
    bool IsGameplayTagValid(FGameplayTag GameplayTag);
    bool HasTag(const FGameplayTagContainer& TagContainer, FGameplayTag Tag, bool bExactMatch);
    bool HasAnyTags(const FGameplayTagContainer& TagContainer, const FGameplayTagContainer& OtherContainer, bool bExactMatch);
    bool HasAllTags(const FGameplayTagContainer& TagContainer, const FGameplayTagContainer& OtherContainer, bool bExactMatch);
    bool HasAllMatchingGameplayTags(TScriptInterface<class IGameplayTagAssetInterface> TagContainerInterface, const FGameplayTagContainer& OtherContainer);
    FName GetTagName(const FGameplayTag& GameplayTag);
    int32 GetNumGameplayTagsInContainer(const FGameplayTagContainer& TagContainer);
    FString GetDebugStringFromGameplayTagContainer(const FGameplayTagContainer& TagContainer);
    FString GetDebugStringFromGameplayTag(FGameplayTag GameplayTag);
    void GetAllActorsOfClassMatchingTagQuery(class UObject* WorldContextObject, TSubclassOf<class AActor> ActorClass, const FGameplayTagQuery& GameplayTagQuery, TArray<class AActor*>& OutActors);
    bool EqualEqual_GameplayTagContainer(const FGameplayTagContainer& A, const FGameplayTagContainer& B);
    bool EqualEqual_GameplayTag(FGameplayTag A, FGameplayTag B);
    bool DoesTagAssetInterfaceHaveTag(TScriptInterface<class IGameplayTagAssetInterface> TagContainerInterface, FGameplayTag Tag);
    bool DoesContainerMatchTagQuery(const FGameplayTagContainer& TagContainer, const FGameplayTagQuery& TagQuery);
    void BreakGameplayTagContainer(const FGameplayTagContainer& GameplayTagContainer, TArray<FGameplayTag>& GameplayTags);
    void AppendGameplayTagContainers(FGameplayTagContainer& InOutTagContainer, const FGameplayTagContainer& InTagContainer);
    void AddGameplayTag(FGameplayTagContainer& TagContainer, FGameplayTag Tag);
};

class IGameplayTagAssetInterface : public IInterface
{

    bool HasMatchingGameplayTag(FGameplayTag TagToCheck);
    bool HasAnyMatchingGameplayTags(const FGameplayTagContainer& TagContainer);
    bool HasAllMatchingGameplayTags(const FGameplayTagContainer& TagContainer);
    void GetOwnedGameplayTags(FGameplayTagContainer& TagContainer);
};

class UEditableGameplayTagQuery : public UObject
{
    FString UserDescription;
    class UEditableGameplayTagQueryExpression* RootExpression;
    FGameplayTagQuery TagQueryExportText_Helper;

};

class UEditableGameplayTagQueryExpression : public UObject
{
};

class UEditableGameplayTagQueryExpression_AnyTagsMatch : public UEditableGameplayTagQueryExpression
{
    FGameplayTagContainer tags;

};

class UEditableGameplayTagQueryExpression_AllTagsMatch : public UEditableGameplayTagQueryExpression
{
    FGameplayTagContainer tags;

};

class UEditableGameplayTagQueryExpression_NoTagsMatch : public UEditableGameplayTagQueryExpression
{
    FGameplayTagContainer tags;

};

class UEditableGameplayTagQueryExpression_AnyExprMatch : public UEditableGameplayTagQueryExpression
{
    TArray<class UEditableGameplayTagQueryExpression*> Expressions;

};

class UEditableGameplayTagQueryExpression_AllExprMatch : public UEditableGameplayTagQueryExpression
{
    TArray<class UEditableGameplayTagQueryExpression*> Expressions;

};

class UEditableGameplayTagQueryExpression_NoExprMatch : public UEditableGameplayTagQueryExpression
{
    TArray<class UEditableGameplayTagQueryExpression*> Expressions;

};

struct FGameplayTagSource
{
    FName SourceName;
    EGameplayTagSourceType SourceType;
    class UGameplayTagsList* SourceTagList;
    class URestrictedGameplayTagsList* SourceRestrictedTagList;

};

class UGameplayTagsManager : public UObject
{
    TMap<class FName, class FGameplayTagSource> TagSources;
    TArray<class UDataTable*> GameplayTagTables;

};

struct FGameplayTagTableRow : public FTableRowBase
{
    FName Tag;
    FString DevComment;

};

class UGameplayTagsList : public UObject
{
    FString ConfigFileName;
    TArray<FGameplayTagTableRow> GameplayTagList;

};

struct FRestrictedGameplayTagTableRow : public FGameplayTagTableRow
{
    bool bAllowNonRestrictedChildren;

};

class URestrictedGameplayTagsList : public UObject
{
    FString ConfigFileName;
    TArray<FRestrictedGameplayTagTableRow> RestrictedGameplayTagList;

};

struct FGameplayTagCategoryRemap
{
    FString BaseCategory;
    TArray<FString> RemapCategories;

};

struct FGameplayTagRedirect
{
    FName OldTagName;
    FName NewTagName;

};

struct FRestrictedConfigInfo
{
    FString RestrictedConfigName;
    TArray<FString> Owners;

};

class UGameplayTagsSettings : public UGameplayTagsList
{
    bool ImportTagsFromConfig;
    bool WarnOnInvalidTags;
    bool ClearInvalidTags;
    bool FastReplication;
    FString InvalidTagCharacters;
    TArray<FGameplayTagCategoryRemap> CategoryRemapping;
    TArray<FSoftObjectPath> GameplayTagTableList;
    TArray<FGameplayTagRedirect> GameplayTagRedirects;
    TArray<FName> CommonlyReplicatedTags;
    int32 NumBitsForContainerSize;
    int32 NetIndexFirstBitSegment;
    TArray<FRestrictedConfigInfo> RestrictedConfigFiles;

};

class UGameplayTagsDeveloperSettings : public UDeveloperSettings
{
    FString DeveloperConfigName;
    FName FavoriteTagSource;

};

struct FGameplayTagCreationWidgetHelper
{
};

struct FGameplayTagReferenceHelper
{
};

struct FGameplayTagNode
{
};

#endif

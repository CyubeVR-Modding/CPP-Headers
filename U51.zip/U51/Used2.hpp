#ifndef UE4SS_SDK_Used2_HPP
#define UE4SS_SDK_Used2_HPP

class UUsed2_C : public UUserWidget
{
    class UImage* Image_0;

};

#endif

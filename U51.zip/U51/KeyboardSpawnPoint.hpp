#ifndef UE4SS_SDK_KeyboardSpawnPoint_HPP
#define UE4SS_SDK_KeyboardSpawnPoint_HPP

class AKeyboardSpawnPoint_C : public AActor
{
    class UArrowComponent* Arrow;

};

#endif

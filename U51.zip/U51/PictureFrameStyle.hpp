#ifndef UE4SS_SDK_PictureFrameStyle_HPP
#define UE4SS_SDK_PictureFrameStyle_HPP

struct FPictureFrameStyle
{
    class UStaticMesh* Corner_2_4E860F2848D73C166C3C1C890631539D;
    bool bMirrorCorners_10_E3C61C76402BFBEBAFCD039AAED454D8;
    class UStaticMesh* Horizontal_5_E5593E4F414F6FD8BB5BA3BD8DDE7FA4;
    EVerticalSideMode VerticalSidesMode_13_402921784D44D042DE8FE1B8EA19CBDE;
    class UStaticMesh* Vertical_6_B34EE4E5435DB5089FC7E0B78B095A5F;
    class UMaterialInterface* VerticalMaterialOverride_16_CAE6FA234F237F91DB1CE1AB47102949;

};

#endif

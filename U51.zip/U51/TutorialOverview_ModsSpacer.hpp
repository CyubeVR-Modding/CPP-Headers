#ifndef UE4SS_SDK_TutorialOverview_ModsSpacer_HPP
#define UE4SS_SDK_TutorialOverview_ModsSpacer_HPP

class UTutorialOverview_ModsSpacer_C : public UUserWidget
{
    class UImage* Image_65;

};

#endif

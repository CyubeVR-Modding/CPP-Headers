#ifndef UE4SS_SDK_TreeManagerBP_HPP
#define UE4SS_SDK_TreeManagerBP_HPP

class ATreeManagerBP_C : public ATreeManager
{
};

#endif

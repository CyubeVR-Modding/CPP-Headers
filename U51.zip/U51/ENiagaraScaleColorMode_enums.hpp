enum class ENiagaraScaleColorMode {
    NewEnumerator0 = 0,
    NewEnumerator1 = 1,
    NewEnumerator2 = 2,
    ENiagaraScaleColorMode_MAX = 3,
};


#ifndef UE4SS_SDK_Enum_ToolsData_HPP
#define UE4SS_SDK_Enum_ToolsData_HPP

struct FEnum_ToolsData
{
    class UTexture2D* WorldTexture_4_617CB96A44021589E2635D910EF80884;
    class UTexture2D* WorldMask_6_D59802594685C2A27EB177AAA3A419DA;
    class UMaterialInstance* UI_Mat_10_A3438B1C44F0D0CFE9D965865C9171FD;

};

#endif

enum class ELocationAccuracy {
    LA_ThreeKilometers = 0,
    LA_OneKilometer = 1,
    LA_HundredMeters = 2,
    LA_TenMeters = 3,
    LA_Best = 4,
    LA_Navigation = 5,
    LA_MAX = 6,
};


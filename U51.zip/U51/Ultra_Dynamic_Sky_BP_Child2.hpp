#ifndef UE4SS_SDK_Ultra_Dynamic_Sky_BP_Child2_HPP
#define UE4SS_SDK_Ultra_Dynamic_Sky_BP_Child2_HPP

class AUltra_Dynamic_Sky_BP_Child2_C : public AUltra_Dynamic_Sky_BP_C
{
};

#endif

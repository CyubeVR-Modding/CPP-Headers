#ifndef UE4SS_SDK_MainMenuSaveGame_HPP
#define UE4SS_SDK_MainMenuSaveGame_HPP

class UMainMenuSaveGame_C : public USaveGame
{
};

#endif

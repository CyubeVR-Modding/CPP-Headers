enum class ETemplateSectionPropertyScaleType {
    FloatProperty = 0,
    TransformPropertyLocationOnly = 1,
    TransformPropertyRotationOnly = 2,
    ETemplateSectionPropertyScaleType_MAX = 3,
};


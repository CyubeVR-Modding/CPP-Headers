#ifndef UE4SS_SDK_FireInterface_HPP
#define UE4SS_SDK_FireInterface_HPP

class IFireInterface_C : public IInterface
{

    void LightOnFire(bool& bpp__Ret__pf);
};

#endif

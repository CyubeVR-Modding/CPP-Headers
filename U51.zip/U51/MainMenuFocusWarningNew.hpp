#ifndef UE4SS_SDK_MainMenuFocusWarningNew_HPP
#define UE4SS_SDK_MainMenuFocusWarningNew_HPP

class UMainMenuFocusWarningNew_C : public UUserWidget
{
    class UWidgetAnimation* WidgetSwitcherChange;
    class UWidgetAnimation* FlyInBorder;
    class UWidgetAnimation* FlyIn;
    class AActor* Parent;

};

#endif

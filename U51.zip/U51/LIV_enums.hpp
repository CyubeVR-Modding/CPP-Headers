enum class ELivEye {
    Center = 0,
    Left = 1,
    Right = 2,
    ELivEye_MAX = 3,
};

enum class ELivSceneViewExtensionCaptureStage {
    PrePostProcess = 0,
    AfterTonemap = 1,
    AfterFXAA = 2,
    ELivSceneViewExtensionCaptureStage_MAX = 3,
};


#ifndef UE4SS_SDK_ImgMediaEngine_HPP
#define UE4SS_SDK_ImgMediaEngine_HPP

class UImgMediaPlaybackComponent : public UActorComponent
{
    float Width;
    float LODBias;

};

#endif

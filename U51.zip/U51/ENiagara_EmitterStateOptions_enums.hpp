enum class ENiagara_EmitterStateOptions {
    NewEnumerator0 = 0,
    NewEnumerator1 = 1,
    NewEnumerator2 = 2,
    ENiagara_MAX = 3,
};


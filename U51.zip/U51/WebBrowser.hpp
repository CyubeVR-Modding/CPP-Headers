#ifndef UE4SS_SDK_WebBrowser_HPP
#define UE4SS_SDK_WebBrowser_HPP

struct FWebJSCallbackBase
{
};

struct FWebJSResponse : public FWebJSCallbackBase
{
};

struct FWebJSFunction : public FWebJSCallbackBase
{
};

#endif

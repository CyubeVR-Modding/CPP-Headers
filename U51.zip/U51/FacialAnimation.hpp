#ifndef UE4SS_SDK_FacialAnimation_HPP
#define UE4SS_SDK_FacialAnimation_HPP

class UAudioCurveSourceComponent : public UAudioComponent
{
    FName CurveSourceBindingName;
    float CurveSyncOffset;

};

#endif

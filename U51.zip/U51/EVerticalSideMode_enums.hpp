enum class EVerticalSideMode {
    NewEnumerator1 = 0,
    NewEnumerator0 = 1,
    NewEnumerator2 = 2,
    EVerticalSideMode_MAX = 3,
};


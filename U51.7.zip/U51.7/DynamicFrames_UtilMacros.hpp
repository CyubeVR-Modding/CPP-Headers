#ifndef UE4SS_SDK_DynamicFrames_UtilMacros_HPP
#define UE4SS_SDK_DynamicFrames_UtilMacros_HPP

class UDynamicFrames_UtilMacros_C : public UObject
{
};

#endif

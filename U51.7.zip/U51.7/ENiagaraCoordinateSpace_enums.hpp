enum class ENiagaraCoordinateSpace {
    NewEnumerator0 = 0,
    NewEnumerator1 = 1,
    NewEnumerator2 = 2,
    ENiagaraCoordinateSpace_0_MAX = 3,
};


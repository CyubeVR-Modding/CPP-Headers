#ifndef UE4SS_SDK_BlockItemVR_NoPhysicsState_HPP
#define UE4SS_SDK_BlockItemVR_NoPhysicsState_HPP

class ABlockItemVR_NoPhysicsState_C : public ABlockItemVR_C
{
};

#endif

#ifndef UE4SS_SDK_MenuGameMode_HPP
#define UE4SS_SDK_MenuGameMode_HPP

class AMenuGameMode_C : public AGameModeBase
{
    class USceneComponent* DefaultSceneRoot;

};

#endif

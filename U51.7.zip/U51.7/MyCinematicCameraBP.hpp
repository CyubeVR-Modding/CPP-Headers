#ifndef UE4SS_SDK_MyCinematicCameraBP_HPP
#define UE4SS_SDK_MyCinematicCameraBP_HPP

class AMyCinematicCameraBP_C : public ACineCameraActor
{
};

#endif

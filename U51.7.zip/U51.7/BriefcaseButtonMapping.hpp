#ifndef UE4SS_SDK_BriefcaseButtonMapping_HPP
#define UE4SS_SDK_BriefcaseButtonMapping_HPP

class UBriefcaseButtonMapping_C : public UUserWidget
{
    FPointerToUberGraphFrame UberGraphFrame;
    class UImage* Image_82;

    void Construct();
    void ExecuteUbergraph_BriefcaseButtonMapping(int32 EntryPoint);
};

#endif

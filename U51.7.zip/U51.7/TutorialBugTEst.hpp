#ifndef UE4SS_SDK_TutorialBugTEst_HPP
#define UE4SS_SDK_TutorialBugTEst_HPP

class UTutorialBugTEst_C : public UUserWidget
{
    class UTutorialOverview_C* TutorialOverview;

};

#endif

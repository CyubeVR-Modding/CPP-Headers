#ifndef UE4SS_SDK_JsonUtilities_HPP
#define UE4SS_SDK_JsonUtilities_HPP

class UJsonUtilitiesDummyObject : public UObject
{
};

struct FJsonObjectWrapper
{
    FString JsonString;

};

#endif

enum class KeyboardTarget {
    NewEnumerator0 = 0,
    NewEnumerator1 = 1,
    KeyboardTarget_MAX = 2,
};


#ifndef UE4SS_SDK_HintTextSave_HPP
#define UE4SS_SDK_HintTextSave_HPP

struct FHintTextSave
{
    bool HasEverMadeProcessedWood_1_40507D9B477C97450C6E73AE03BAE7B7;
    bool HasEverPlacedATorch_3_051E76A14E2F484C926F94A71F0B3B71;
    bool HasEverCraftedAnything_5_334E95D843F136D2025F4E862AAA523F;

};

#endif

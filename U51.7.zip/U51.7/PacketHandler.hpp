#ifndef UE4SS_SDK_PacketHandler_HPP
#define UE4SS_SDK_PacketHandler_HPP

class UHandlerComponentFactory : public UObject
{
};

class UPacketHandlerProfileConfig : public UObject
{
    TArray<FString> Components;

};

#endif

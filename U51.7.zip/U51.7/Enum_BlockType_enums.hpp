enum class Enum_BlockType {
    NewEnumerator1 = 0,
    NewEnumerator3 = 1,
    NewEnumerator2 = 2,
    NewEnumerator4 = 3,
    NewEnumerator5 = 4,
    NewEnumerator6 = 5,
    NewEnumerator7 = 6,
    NewEnumerator8 = 7,
    Enum_MAX = 8,
};


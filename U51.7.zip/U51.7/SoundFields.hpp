#ifndef UE4SS_SDK_SoundFields_HPP
#define UE4SS_SDK_SoundFields_HPP

class UAmbisonicsEncodingSettings : public USoundfieldEncodingSettingsBase
{
    int32 AmbisonicsOrder;

};

#endif

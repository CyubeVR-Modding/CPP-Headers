enum class ESteamVRTrackedDeviceType {
    Controller = 0,
    TrackingReference = 1,
    Other = 2,
    Invalid = 3,
    ESteamVRTrackedDeviceType_MAX = 4,
};


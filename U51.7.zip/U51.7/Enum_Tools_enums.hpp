enum class Enum_Tools {
    NewEnumerator3 = 0,
    NewEnumerator1 = 1,
    NewEnumerator0 = 2,
    NewEnumerator2 = 3,
    NewEnumerator4 = 4,
    Enum_MAX = 5,
};


#ifndef UE4SS_SDK_HintTextSaveGame_HPP
#define UE4SS_SDK_HintTextSaveGame_HPP

class UHintTextSaveGame_C : public USaveGame
{
    FHintTextSave HintTextSave;

};

#endif

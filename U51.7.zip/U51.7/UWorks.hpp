#ifndef UE4SS_SDK_UWorks_HPP
#define UE4SS_SDK_UWorks_HPP

class UUWorks : public UObject
{
};

class UUWorksInterface : public UUWorks
{
};

class UUWorksRequest : public UUWorks
{
};

struct FUWorksSteamID
{
};

struct FUWorksGameID
{
};

struct FUWorksSteamItemDef
{
    int32 Value;

};

struct FUWorksSteamItemInstanceID
{
};

struct FUWorksPublishedFileID
{
};

#endif

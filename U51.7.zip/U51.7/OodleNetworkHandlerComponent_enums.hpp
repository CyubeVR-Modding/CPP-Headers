enum class EOodleEnableMode {
    AlwaysEnabled = 0,
    WhenCompressedPacketReceived = 1,
    EOodleEnableMode_MAX = 2,
};


#ifndef UE4SS_SDK_OnlineSubsystemUWorks_HPP
#define UE4SS_SDK_OnlineSubsystemUWorks_HPP

class UIpConnectionUWorks : public UIpConnection
{
};

class UIpNetDriverUWorks : public UIpNetDriver
{
};

#endif

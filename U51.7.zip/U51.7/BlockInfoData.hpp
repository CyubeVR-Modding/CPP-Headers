#ifndef UE4SS_SDK_BlockInfoData_HPP
#define UE4SS_SDK_BlockInfoData_HPP

struct FBlockInfoData
{
    Enum_BlockType Type_2_19426B64462F34CB454420A8CF2E23AE;
    bool InstantDestroy_7_56A8A42F489444889AC9939D99E7C368;
    class UTexture2D* ParticleTexture_8_01304CA041BDC42520E2F2BB6193DC1E;
    class UMaterialInstance* BlockMaterial_14_022B1FEE4DEF4BA1BB815585908AC8CD;
    class UStaticMesh* Mesh_17_FBCDB3FA489F95D7BC7B7DA1B2A0281D;
    class UMaterialInstance* UI_Material_20_C7403111440FA67B74B6F19C4357E145;

};

#endif

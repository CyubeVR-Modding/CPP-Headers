enum class ENiagaraSkelMeshPositionSamplingMode {
    NewEnumerator0 = 0,
    NewEnumerator1 = 1,
    NewEnumerator2 = 2,
    ENiagaraSkelMeshPositionSamplingMode_MAX = 3,
};


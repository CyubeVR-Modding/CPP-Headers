#ifndef UE4SS_SDK_NativizedAssets_HPP
#define UE4SS_SDK_NativizedAssets_HPP

class U__Delegates__ABlockItemVR_C__pf2937682852 : public UObject
{
};

class U__Delegates__AFirstPersonCharacterVR_C__pf205484891 : public UObject
{
};

#endif

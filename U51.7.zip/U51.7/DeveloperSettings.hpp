#ifndef UE4SS_SDK_DeveloperSettings_HPP
#define UE4SS_SDK_DeveloperSettings_HPP

class UDeveloperSettings : public UObject
{
};

#endif

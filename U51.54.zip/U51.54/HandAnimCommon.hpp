#ifndef UE4SS_SDK_HandAnimCommon_HPP
#define UE4SS_SDK_HandAnimCommon_HPP

class UHandAnimCommon_C : public UAnimInstance
{
};

#endif

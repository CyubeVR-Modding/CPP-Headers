#ifndef UE4SS_SDK_SignificanceManager_HPP
#define UE4SS_SDK_SignificanceManager_HPP

class USignificanceManager : public UObject
{
    FSoftClassPath SignificanceManagerClassName;

};

#endif

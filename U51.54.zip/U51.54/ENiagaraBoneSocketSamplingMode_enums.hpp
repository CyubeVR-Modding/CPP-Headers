enum class ENiagaraBoneSocketSamplingMode {
    NewEnumerator0 = 0,
    NewEnumerator5 = 1,
    ENiagaraBoneSocketSamplingMode_MAX = 2,
};


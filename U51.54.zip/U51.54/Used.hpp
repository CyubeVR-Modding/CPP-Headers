#ifndef UE4SS_SDK_Used_HPP
#define UE4SS_SDK_Used_HPP

class UUsed_C : public UUserWidget
{
};

#endif

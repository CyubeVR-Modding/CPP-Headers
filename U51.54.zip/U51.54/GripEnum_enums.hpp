enum class GripEnum {
    NewEnumerator0 = 0,
    NewEnumerator1 = 1,
    NewEnumerator2 = 2,
    GripEnum_MAX = 3,
};


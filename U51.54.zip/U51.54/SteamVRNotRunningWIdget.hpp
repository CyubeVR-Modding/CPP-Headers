#ifndef UE4SS_SDK_SteamVRNotRunningWIdget_HPP
#define UE4SS_SDK_SteamVRNotRunningWIdget_HPP

class USteamVRNotRunningWIdget_C : public UUserWidget
{
    class UImage* Image_20;

};

#endif

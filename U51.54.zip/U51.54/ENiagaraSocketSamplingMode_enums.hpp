enum class ENiagaraSocketSamplingMode {
    NewEnumerator0 = 0,
    NewEnumerator5 = 1,
    ENiagaraSocketSamplingMode_MAX = 2,
};


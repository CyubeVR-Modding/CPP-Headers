#ifndef UE4SS_SDK_LightPropagationVolumeRuntime_HPP
#define UE4SS_SDK_LightPropagationVolumeRuntime_HPP

class ULightPropagationVolumeBlendable : public UObject
{
    FLightPropagationVolumeSettings Settings;
    float BlendWeight;

};

#endif

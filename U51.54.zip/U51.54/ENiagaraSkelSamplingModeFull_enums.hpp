enum class ENiagaraSkelSamplingModeFull {
    NewEnumerator0 = 0,
    NewEnumerator5 = 1,
    NewEnumerator6 = 2,
    NewEnumerator7 = 3,
    NewEnumerator8 = 4,
    ENiagaraSkelSamplingModeFull_MAX = 5,
};


#ifndef UE4SS_SDK_BenchmarkEndSaveGame_HPP
#define UE4SS_SDK_BenchmarkEndSaveGame_HPP

class UBenchmarkEndSaveGame_C : public USaveGame
{
    bool ShowName;

};

#endif

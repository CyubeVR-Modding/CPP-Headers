enum class ENiagara_InfiniteLoopDuration {
    NewEnumerator0 = 0,
    NewEnumerator1 = 1,
    ENiagara_MAX = 2,
};


enum class ItemType {
    NewEnumerator0 = 0,
    NewEnumerator1 = 1,
    NewEnumerator2 = 2,
    ItemType_MAX = 3,
};


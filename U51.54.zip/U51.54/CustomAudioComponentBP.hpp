#ifndef UE4SS_SDK_CustomAudioComponentBP_HPP
#define UE4SS_SDK_CustomAudioComponentBP_HPP

class UCustomAudioComponentBP_C : public UCustomAudioComponent
{
};

#endif

#ifndef UE4SS_SDK_SphereActor_HPP
#define UE4SS_SDK_SphereActor_HPP

class ASphereActor_C : public AActor
{
    class UStaticMeshComponent* SphereMesh;
    class UPhysicsConstraintComponent* PhysicsConstraint;

};

#endif

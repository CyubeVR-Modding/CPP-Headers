enum class hand {
    NewEnumerator0 = 0,
    NewEnumerator1 = 1,
    Hand_MAX = 2,
};


enum class ELobbyBeaconJoinState {
    None = 0,
    SentJoinRequest = 1,
    JoinRequestAcknowledged = 2,
    ELobbyBeaconJoinState_MAX = 3,
};


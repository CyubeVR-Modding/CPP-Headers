enum class Environment {
    NewEnumerator0 = 0,
    NewEnumerator1 = 1,
    Environment_MAX = 2,
};


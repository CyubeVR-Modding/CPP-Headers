#ifndef UE4SS_SDK_BP_MacroLibraryObject_HPP
#define UE4SS_SDK_BP_MacroLibraryObject_HPP

class UBP_MacroLibraryObject_C : public UObject
{
};

#endif

#ifndef UE4SS_SDK_DynamicBlockPreview_HPP
#define UE4SS_SDK_DynamicBlockPreview_HPP

class UDynamicBlockPreview_C : public UUserWidget
{
    class UImage* Left;
    class URetainerBox* RetainerBox_0;
    class UImage* Right;
    class UImage* Top;

};

#endif

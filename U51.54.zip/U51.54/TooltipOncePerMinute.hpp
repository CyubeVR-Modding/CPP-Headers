#ifndef UE4SS_SDK_TooltipOncePerMinute_HPP
#define UE4SS_SDK_TooltipOncePerMinute_HPP

class UTooltipOncePerMinute_C : public UUserWidget
{
};

#endif

#ifndef UE4SS_SDK_BP_DynamicFrame_Copper_HPP
#define UE4SS_SDK_BP_DynamicFrame_Copper_HPP

class ABP_DynamicFrame_Copper_C : public ABP_DynamicFrame_Gold_C
{
};

#endif

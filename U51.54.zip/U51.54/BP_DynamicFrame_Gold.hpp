#ifndef UE4SS_SDK_BP_DynamicFrame_Gold_HPP
#define UE4SS_SDK_BP_DynamicFrame_Gold_HPP

class ABP_DynamicFrame_Gold_C : public ABP_DynamicFrame_C
{
};

#endif

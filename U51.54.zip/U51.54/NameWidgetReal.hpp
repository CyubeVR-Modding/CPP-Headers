#ifndef UE4SS_SDK_NameWidgetReal_HPP
#define UE4SS_SDK_NameWidgetReal_HPP

class UNameWidgetReal_C : public UUserWidget
{
    class UImage* Image_0;

};

#endif
